#pragma once
#include <string>
#include <iostream>

void json_parser(std::string json);
void array_parser(std::string json);


